/* main.js – Carrito global para PA3
   - Compatible con páginas que ya contienen #cart-root (en el header) o sin él.
   - Delegación de eventos para .add-to-cart
   - Persistente vía localStorage
   - Operaciones: agregar, aumentar, disminuir, quitar, vaciar, pagar
*/

/* ================================
   CONFIG
   ================================ */
const AppConfig = {
  storageKey: "conectec_cart_v1",
  currency: "S/",
  selectors: {
    cartRoot: "#cart-root",
    cartToggle: "#cart-toggle",
    cartPanel: "#cart-panel",
    cartClose: "#cart-close",
    cartCount: "#cart-count",
    cartItems: "#cart-items",
    cartTotal: "#cart-total",
    cartClear: "#cart-clear",
    cartCheckout: "#cart-checkout",
    cartContent: "#cart-content",
    addToCart: ".add-to-cart"
  }
};

const $ = sel => document.querySelector(sel);
const $$ = sel => Array.from(document.querySelectorAll(sel));

/* ================================
   MODELOS
   ================================ */
class Product {
  constructor(id, title, price, meta = {}) {
    this.id = String(id);
    this.title = title;
    this.price = Number(price) || 0;
    this.meta = meta;
  }
  displayName() {
    return this.title;
  }
  toJSON() {
    return { id: this.id, title: this.title, price: this.price, meta: this.meta };
  }
}
class ServiceProduct extends Product {
  displayName() {
    return `${this.title} — ${this.meta.short || "Servicio"}`;
  }
}
Product.prototype.short = function (len = 40) {
  return this.title.length > len ? this.title.slice(0, len).trim() + "…" : this.title;
};

/* ================================
   CART
   ================================ */
class Cart {
  constructor(storageKey) {
    this.storageKey = storageKey;
    this.items = new Map();
    this.load();
  }

  add(product, qty = 1) {
    const id = String(product.id);
    const existing = this.items.get(id);
    if (existing) existing.qty += qty;
    else this.items.set(id, { product, qty });
    this.save();
  }

  remove(id) {
    this.items.delete(String(id));
    this.save();
  }

  setQty(id, qty) {
    qty = Math.max(0, Math.floor(Number(qty) || 0));
    const strId = String(id);
    const item = this.items.get(strId);
    if (!item) return;
    if (qty === 0) this.items.delete(strId);
    else item.qty = qty;
    this.save();
  }

  clear() {
    this.items.clear();
    this.save();
  }

  getCount() {
    let sum = 0;
    for (const [, v] of this.items) sum += v.qty;
    return sum;
  }

  // recursiva (criterio PA3)
  totalRecursive(arr = Array.from(this.items.values()), i = 0) {
    return i >= arr.length ? 0 : arr[i].product.price * arr[i].qty + this.totalRecursive(arr, i + 1);
  }

  getTotal() {
    return Number(this.totalRecursive().toFixed(2));
  }

  save() {
    try {
      const payload = [...this.items].map(([id, obj]) => [id, { product: obj.product.toJSON(), qty: obj.qty }]);
      localStorage.setItem(this.storageKey, JSON.stringify(payload));
      document.dispatchEvent(new CustomEvent("cart:updated"));
    } catch (e) {
      console.error("Cart save error:", e);
    }
  }

  load() {
    try {
      const raw = localStorage.getItem(this.storageKey);
      if (!raw) return;
      const arr = JSON.parse(raw);
      this.items = new Map(
        arr.map(([id, obj]) => [
          id,
          {
            product: new Product(obj.product.id, obj.product.title, obj.product.price, obj.product.meta),
            qty: obj.qty
          }
        ])
      );
    } catch (e) {
      console.error("Cart load error:", e);
      this.items = new Map();
    }
  }
}

const cart = new Cart(AppConfig.storageKey);

/* ================================
   UI: Crear / Asegurar HTML del carrito
   ================================ */
function ensureCartDOM() {
  let root = $(AppConfig.selectors.cartRoot);

  // Si no existe cart-root crearlo y colocarlo en header si existe, o en body
  if (!root) {
    root = document.createElement("div");
    root.id = AppConfig.selectors.cartRoot.replace("#", "");
    // intenta colocarlo en header si existe
    const header = document.querySelector(".header");
    if (header) header.appendChild(root);
    else document.body.appendChild(root);
  }

  // si dentro del root no existe botón toggle, crear uno (mantener compatibilidad)
  if (!$(AppConfig.selectors.cartToggle)) {
    const btn = document.createElement("button");
    btn.id = AppConfig.selectors.cartToggle.replace("#", "");
    btn.setAttribute("aria-label", "Abrir carrito");
    btn.innerHTML = `🛒 <span id="${AppConfig.selectors.cartCount.replace("#", "")}">${cart.getCount()}</span>`;
    // intenta ubicarlo al final del root sin romper el layout
    root.appendChild(btn);
  }

  // si no existe panel, añadir panel básico (no sobreescribe si ya existe)
  if (!$(AppConfig.selectors.cartPanel)) {
    const panel = document.createElement("aside");
    panel.id = AppConfig.selectors.cartPanel.replace("#", "");
    panel.setAttribute("aria-hidden", "true");
    panel.innerHTML = `
      <header class="cart-header">
        <h3>Carrito</h3>
        <button id="${AppConfig.selectors.cartClose.replace("#", "")}" aria-label="Cerrar carrito">✕</button>
      </header>
      <div id="${AppConfig.selectors.cartContent.replace("#", "")}">
        <p class="empty">Tu carrito está vacío.</p>
        <ul id="${AppConfig.selectors.cartItems.replace("#", "")}" class="cart-items" aria-live="polite"></ul>
      </div>
      <footer class="cart-footer">
        <div style="display:flex;justify-content:space-between;align-items:center;">
          <div>Total: <strong>${AppConfig.currency}<span id="${AppConfig.selectors.cartTotal.replace("#", "")}">0.00</span></strong></div>
        </div>
        <div style="display:flex;gap:0.5rem;margin-top:0.6rem;">
          <button id="${AppConfig.selectors.cartClear.replace("#", "")}" type="button">Vaciar</button>
          <button id="${AppConfig.selectors.cartCheckout.replace("#", "")}" type="button">Pagar</button>
        </div>
      </footer>
    `;
    // añadimos después del botón toggle si existe, sino al final del root
    const toggle = $(AppConfig.selectors.cartToggle);
    if (toggle && toggle.parentNode === root) root.appendChild(panel);
    else root.appendChild(panel);
  }

  // asegurar que exista #cart-count (puede haber sido creado dentro del toggle anterior)
  if (!$(AppConfig.selectors.cartCount)) {
    const toggle = $(AppConfig.selectors.cartToggle);
    if (toggle) {
      const span = document.createElement("span");
      span.id = AppConfig.selectors.cartCount.replace("#", "");
      span.textContent = cart.getCount();
      toggle.appendChild(span);
    }
  }
}

/* ================================
   RENDERIZADO
   ================================ */
function renderCartCount() {
  const el = $(AppConfig.selectors.cartCount);
  if (el) el.textContent = cart.getCount();
}

function renderCartPanel() {
  const list = $(AppConfig.selectors.cartItems);
  const total = $(AppConfig.selectors.cartTotal);
  const content = $(AppConfig.selectors.cartContent);
  if (!list || !total || !content) return;

  list.innerHTML = "";

  if (cart.items.size === 0) {
    const empty = content.querySelector(".empty");
    if (empty) empty.hidden = false;
    list.hidden = true;
    total.textContent = "0.00";
    return;
  }

  const empty = content.querySelector(".empty");
  if (empty) empty.hidden = true;
  list.hidden = false;

  for (const [id, entry] of cart.items) {
    const li = document.createElement("li");
    li.className = "cart-item";
    li.dataset.id = id;

    li.innerHTML = `
      <div class="meta">
        <h4>${entry.product.displayName()}</h4>
        <p>${entry.product.short()} — ${AppConfig.currency}${entry.product.price.toFixed(2)}</p>
        <div class="cart-row">
          <button class="dec" aria-label="Disminuir">−</button>
          <span class="qty" aria-live="polite">${entry.qty}</span>
          <button class="inc" aria-label="Aumentar">+</button>
          <button class="remove" aria-label="Eliminar">🗑</button>
        </div>
      </div>
    `;

    list.appendChild(li);
  }

  total.textContent = cart.getTotal().toFixed(2);
}

/* ================================
   APERTURA / CIERRE
   ================================ */
function openCart() {
  const panel = $(AppConfig.selectors.cartPanel);
  if (!panel) return;
  panel.setAttribute("aria-hidden", "false");
  // focus-friendly
  const close = $(AppConfig.selectors.cartClose);
  if (close) close.focus();
}

function closeCart() {
  const panel = $(AppConfig.selectors.cartPanel);
  if (!panel) return;
  panel.setAttribute("aria-hidden", "true");
}

/* ================================
   BIND EVENTS (delegación + tolerancia)
   ================================ */
function bindUI() {
  // Toggle abrir/cerrar
  document.addEventListener("click", (e) => {
    // abrir carrito: click en #cart-toggle o cualquier elemento dentro
    if (e.target.closest(AppConfig.selectors.cartToggle)) {
      openCart();
      return;
    }
    // cerrar si click en #cart-close
    if (e.target.closest(AppConfig.selectors.cartClose)) {
      closeCart();
      return;
    }
  });

  // tecla Escape cierra
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") closeCart();
  });

  // Delegación sobre panel para botones inc/dec/remove
  const panel = $(AppConfig.selectors.cartPanel);
  if (panel) {
    panel.addEventListener("click", (e) => {
      const itemEl = e.target.closest(".cart-item");
      if (!itemEl) return;
      const id = itemEl.dataset.id;
      if (!id) return;

      if (e.target.classList.contains("inc")) {
        cart.setQty(id, (cart.items.get(id).qty || 0) + 1);
      } else if (e.target.classList.contains("dec")) {
        cart.setQty(id, (cart.items.get(id).qty || 0) - 1);
      } else if (e.target.classList.contains("remove")) {
        cart.remove(id);
      }

      renderCartPanel();
      renderCartCount();
    });
  }

  // Vaciar y pagar (delegación document para tolerancia)
  document.addEventListener("click", (e) => {
    if (e.target.closest(AppConfig.selectors.cartClear)) {
      if (confirm("¿Deseas vaciar el carrito?")) {
        cart.clear();
        renderCartPanel();
        renderCartCount();
      }
    }
    if (e.target.closest(AppConfig.selectors.cartCheckout)) {
      if (cart.getCount() === 0) {
        alert("El carrito está vacío.");
        return;
      }
      // simulación de checkout
      alert(`Total a pagar: ${AppConfig.currency}${cart.getTotal().toFixed(2)}\nGracias por tu compra (simulado).`);
      cart.clear();
      renderCartPanel();
      renderCartCount();
    }
  });

  // Actualizar contador cuando cart emite evento
  document.addEventListener("cart:updated", () => {
    renderCartCount();
    renderCartPanel();
  });
}

/* ================================
   ADD TO CART: delegación global (funciona en todas las páginas)
   - Espera que los botones tengan clase .add-to-cart
   - Puede leer data-name y data-price, o buscar en el DOM (h3, p)
   ================================ */
function bindAddToCartDelegation() {
  document.addEventListener("click", (e) => {
    const btn = e.target.closest(AppConfig.selectors.addToCart);
    if (!btn) return;

    // evitar que el <a> o formulario haga navegación
    e.preventDefault();

    // obtener datos del botón o del contenedor
    const container = btn.closest(".card-servicio, .producto, article, .card, .card-servicio") || btn.parentElement;
    const name = btn.dataset.name || (container && container.querySelector("h3")?.textContent.trim()) || "Producto";
    const price = Number(btn.dataset.price ?? container?.dataset?.price ?? container?.querySelector(".price")?.textContent?.replace(/[^\d.,]/g, "") ?? 0) || 0;
    const id = btn.dataset.id || btn.dataset.name || (container && (container.dataset.id || container.querySelector("h3")?.textContent.trim().replace(/\s+/g, "-").toLowerCase())) || `p-${Date.now()}`;

    // elegir clase de producto acorde (ejemplo simple de polimorfismo)
    const product = name.toLowerCase().includes("servicio")
      ? new ServiceProduct(id, name, price, { short: name.split(" ").slice(0, 3).join(" ") })
      : new Product(id, name, price, { short: name.split(" ").slice(0, 6).join(" ") });

    cart.add(product, 1);
    // actualizar UI
    renderCartCount();
    renderCartPanel();
    openCart();
  });
}

/* ================================
   INICIALIZACIÓN
   ================================ */
function init() {
  ensureCartDOM();
  bindUI();
  bindAddToCartDelegation();
  // render inicial
  renderCartCount();
  renderCartPanel();
}

// arrancar cuando DOM esté listo
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", init);
} else {
  init();
}
